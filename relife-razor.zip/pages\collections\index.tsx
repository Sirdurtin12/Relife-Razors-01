import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import { useRouter } from 'next/router'
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react'
import Link from 'next/link'
import RazorListItem from '../../components/razors/RazorListItem'
import { UserCollection, UserRating } from '../../lib/supabase'
import CollectionShareButton from '../../components/collections/CollectionShareButton'

const CollectionPage = () => {
  const router = useRouter()
  const supabaseClient = useSupabaseClient()
  const user = useUser()
  
  // États pour les données de la collection
  const [ownedRazors, setOwnedRazors] = useState<UserCollection[]>([])
  const [interestedRazors, setInterestedRazors] = useState<UserCollection[]>([])
  const [favoriteRazors, setFavoriteRazors] = useState<UserCollection[]>([])
  const [activeTab, setActiveTab] = useState<'collection' | 'wishlist' | 'favorites'>('collection')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // États pour la recherche et le filtrage
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [filterManufacturer, setFilterManufacturer] = useState<string>('')
  const [manufacturers, setManufacturers] = useState<string[]>([])
  
  // Fonction pour initialiser les ratings manquants
  const initializeFavoriteRatings = async () => {
    if (!user || favoriteRazors.length === 0) return;
    
    console.log('Initializing favorite ratings');
    
    try {
      // Vérifier si des rasoirs n'ont pas de rating
      const razorsWithoutRating = favoriteRazors.filter(razor => razor.favorite_rating === null);
      
      if (razorsWithoutRating.length === 0) {
        console.log('All favorite razors already have ratings');
        return;
      }
      
      console.log(`Found ${razorsWithoutRating.length} razors without ratings`);
      
      // Assigner des ratings séquentiels en commençant par le plus haut disponible
      const highestRating = Math.max(...favoriteRazors
        .filter(razor => razor.favorite_rating !== null)
        .map(razor => razor.favorite_rating || 0), 0);
      
      let nextRating = highestRating + 1;
      
      // Mettre à jour chaque rasoir sans rating
      for (const razor of razorsWithoutRating) {
        console.log(`Assigning rating ${nextRating} to razor ${razor.razor_id}`);
        
        const { error } = await supabaseClient
          .from('user_collections')
          .update({ favorite_rating: nextRating })
          .eq('id', razor.id);
        
        if (error) {
          console.error('Error updating rating:', error);
        } else {
          nextRating++;
        }
      }
      
      // Recharger les données des favoris
      await fetchFavorites();
      
    } catch (err) {
      console.error('Error initializing favorite ratings:', err);
    }
  };
  
  // Fonction pour récupérer les favoris
  const fetchFavorites = async () => {
    if (!user) return;
    
    try {
      const { data } = await supabaseClient
        .from('user_collections')
        .select(`
          id,
          razor_id,
          in_wishlist,
          is_favorite,
          favorite_rating,
          variant_material,
          variant_finish,
          variant_comb_type,
          variant_notes,
          is_variant,
          razors (
            id,
            manufacturer,
            model,
            reference,
            image_url,
            blade_type,
            avg_gentleness
          )
        `)
        .eq('user_id', user.id)
        .eq('is_favorite', true)
        .order('favorite_rating', { ascending: false, nullsLast: true });
      
      if (data) {
        setFavoriteRazors(data);
        return data;
      }
    } catch (err) {
      console.error('Error fetching favorites:', err);
    }
    
    return [];
  };

  // Fonctions pour gérer l'ordre des favoris
  const handleMoveUp = async (position: number) => {
    if (position <= 1 || !user) return;
    
    console.log('handleMoveUp called with position:', position);
    
    try {
      // Vérifier si tous les rasoirs ont un rating, sinon les initialiser
      const hasNullRatings = favoriteRazors.some(razor => razor.favorite_rating === null);
      if (hasNullRatings) {
        console.log('Some favorite razors have null ratings, initializing...');
        await initializeFavoriteRatings();
        return; // Sortir pour permettre à l'utilisateur de réessayer après l'initialisation
      }
      
      // Trouver les deux rasoirs à échanger
      const currentRazor = favoriteRazors.find((_, index) => index + 1 === position);
      const upRazor = favoriteRazors.find((_, index) => index + 1 === position - 1);
      
      console.log('Current razor:', currentRazor);
      console.log('Up razor:', upRazor);
      
      if (!currentRazor || !upRazor) {
        console.log('Could not find razors to swap');
        return;
      }
      
      // S'assurer que les deux rasoirs ont des ratings valides
      if (currentRazor.favorite_rating === null || upRazor.favorite_rating === null) {
        console.log('One of the razors has a null rating');
        await initializeFavoriteRatings();
        return;
      }
      
      // Échanger les ratings
      const currentRating = currentRazor.favorite_rating;
      const upRating = upRazor.favorite_rating;
      
      // Mettre à jour le rasoir courant avec la nouvelle position
      const { error: updateCurrentError } = await supabaseClient
        .from('user_collections')
        .update({ favorite_rating: upRating })
        .eq('id', currentRazor.id);
      
      if (updateCurrentError) throw updateCurrentError;
      
      // Mettre à jour le rasoir supérieur avec la nouvelle position
      const { error: updateUpError } = await supabaseClient
        .from('user_collections')
        .update({ favorite_rating: currentRating })
        .eq('id', upRazor.id);
      
      if (updateUpError) throw updateUpError;
      
      // Recharger les données
      const { data } = await supabaseClient
        .from('user_collections')
        .select(`
          id,
          razor_id,
          in_wishlist,
          is_favorite,
          favorite_rating,
          variant_material,
          variant_finish,
          variant_comb_type,
          variant_notes,
          is_variant,
          razors (
            id,
            manufacturer,
            model,
            reference,
            image_url,
            blade_type,
            avg_gentleness
          )
        `)
        .eq('user_id', user.id)
        .eq('is_favorite', true)
        .order('favorite_rating', { ascending: false, nullsLast: true });
      
      if (data) {
        setFavoriteRazors(data);
      }
      
    } catch (err) {
      console.error('Erreur lors du déplacement du rasoir:', err);
    }
  };
  
  const handleMoveDown = async (position: number) => {
    if (position >= favoriteRazors.length || !user) return;
    
    console.log('handleMoveDown called with position:', position);
    
    try {
      // Vérifier si tous les rasoirs ont un rating, sinon les initialiser
      const hasNullRatings = favoriteRazors.some(razor => razor.favorite_rating === null);
      if (hasNullRatings) {
        console.log('Some favorite razors have null ratings, initializing...');
        await initializeFavoriteRatings();
        return; // Sortir pour permettre à l'utilisateur de réessayer après l'initialisation
      }
      
      // Trouver les deux rasoirs à échanger
      const currentRazor = favoriteRazors.find((_, index) => index + 1 === position);
      const downRazor = favoriteRazors.find((_, index) => index + 1 === position + 1);
      
      console.log('Current razor:', currentRazor);
      console.log('Down razor:', downRazor);
      
      if (!currentRazor || !downRazor) {
        console.log('Could not find razors to swap');
        return;
      }
      
      // S'assurer que les deux rasoirs ont des ratings valides
      if (currentRazor.favorite_rating === null || downRazor.favorite_rating === null) {
        console.log('One of the razors has a null rating');
        await initializeFavoriteRatings();
        return;
      }
      
      // Échanger les ratings
      const currentRating = currentRazor.favorite_rating;
      const downRating = downRazor.favorite_rating;
      
      // Mettre à jour le rasoir courant avec la nouvelle position
      const { error: updateCurrentError } = await supabaseClient
        .from('user_collections')
        .update({ favorite_rating: downRating })
        .eq('id', currentRazor.id);
      
      if (updateCurrentError) throw updateCurrentError;
      
      // Mettre à jour le rasoir inférieur avec la nouvelle position
      const { error: updateDownError } = await supabaseClient
        .from('user_collections')
        .update({ favorite_rating: currentRating })
        .eq('id', downRazor.id);
      
      if (updateDownError) throw updateDownError;
      
      // Recharger les données
      const { data } = await supabaseClient
        .from('user_collections')
        .select(`
          id,
          razor_id,
          in_wishlist,
          is_favorite,
          favorite_rating,
          variant_material,
          variant_finish,
          variant_comb_type,
          variant_notes,
          is_variant,
          razors (
            id,
            manufacturer,
            model,
            reference,
            image_url,
            blade_type,
            avg_gentleness
          )
        `)
        .eq('user_id', user.id)
        .eq('is_favorite', true)
        .order('favorite_rating', { ascending: false, nullsLast: true });
      
      if (data) {
        setFavoriteRazors(data);
      }
      
    } catch (err) {
      console.error('Erreur lors du déplacement du rasoir:', err);
    }
  };
  
  const handleRemoveFavorite = async (razorId: number) => {
    if (!user) return;
    
    try {
      if (window.confirm('Êtes-vous sûr de vouloir retirer ce rasoir de vos favoris ?')) {
        // Mettre à jour le rasoir pour le retirer des favoris
        const { error } = await supabaseClient
          .from('user_collections')
          .update({ is_favorite: false, favorite_rating: null })
          .eq('user_id', user.id)
          .eq('razor_id', razorId);
        
        if (error) throw error;
        
        // Mettre à jour la liste des favoris
        setFavoriteRazors(favoriteRazors.filter(item => item.razor_id !== razorId));
      }
    } catch (err) {
      console.error('Erreur lors de la suppression du favori:', err);
    }
  };

  // Rasoirs filtrés
  const filteredOwnedRazors = ownedRazors.filter(item => {
    const matchesSearch = searchTerm === '' || 
      (item.razors && 
        (item.razors.manufacturer?.toLowerCase().includes(searchTerm.toLowerCase()) || 
         item.razors.model?.toLowerCase().includes(searchTerm.toLowerCase()) ||
         item.razors.name?.toLowerCase().includes(searchTerm.toLowerCase())));
    
    const matchesManufacturer = filterManufacturer === '' || 
      (item.razors && item.razors.manufacturer === filterManufacturer);
    
    return matchesSearch && matchesManufacturer;
  });
  
  const filteredInterestedRazors = interestedRazors.filter(item => {
    const matchesSearch = searchTerm === '' || 
      (item.razors && 
        (item.razors.manufacturer?.toLowerCase().includes(searchTerm.toLowerCase()) || 
         item.razors.model?.toLowerCase().includes(searchTerm.toLowerCase()) ||
         item.razors.name?.toLowerCase().includes(searchTerm.toLowerCase())));
    
    const matchesManufacturer = filterManufacturer === '' || 
      (item.razors && item.razors.manufacturer === filterManufacturer);
    
    return matchesSearch && matchesManufacturer;
  });
  
  // Vérifier si nous sommes côté client
  useEffect(() => {
    if (!user && typeof window !== 'undefined') {
      router.push('/auth/signin?redirect=/collections')
    }
  }, [user, router])
  
  // Charger les données de la collection
  useEffect(() => {
    const fetchCollectionData = async () => {
      setLoading(true);
      try {
        if (!user) return;
        
        // Récupérer les rasoirs possédés (ceux qui ne sont pas dans la liste de souhaits)
        const { data: ownedRazorsData } = await supabaseClient
          .from('user_collections')
          .select(`
            id,
            razor_id,
            in_wishlist,
            is_favorite,
            variant_material,
            variant_finish,
            variant_comb_type,
            variant_notes,
            is_variant,
            razors (
              id,
              manufacturer,
              model,
              reference,
              image_url,
              blade_type,
              avg_gentleness
            )
          `)
          .eq('user_id', user.id)
          .eq('in_wishlist', false)
        
        if (ownedRazorsData) {
          setOwnedRazors(ownedRazorsData)
        }
        
        // Récupérer les rasoirs qui intéressent l'utilisateur
        const { data: interestedRazorsData } = await supabaseClient
          .from('user_collections')
          .select(`
            id,
            razor_id,
            in_wishlist,
            is_favorite,
            variant_material,
            variant_finish,
            variant_comb_type,
            variant_notes,
            is_variant,
            razors (
              id,
              manufacturer,
              model,
              reference,
              image_url,
              blade_type,
              avg_gentleness
            )
          `)
          .eq('user_id', user.id)
          .eq('in_wishlist', true)
        
        if (interestedRazorsData) {
          setInterestedRazors(interestedRazorsData)
        }
        
        // Récupérer les rasoirs favoris
        const { data: favoriteRazorsData } = await supabaseClient
          .from('user_collections')
          .select(`
            id,
            razor_id,
            in_wishlist,
            is_favorite,
            favorite_rating,
            variant_material,
            variant_finish,
            variant_comb_type,
            variant_notes,
            is_variant,
            razors (
              id,
              manufacturer,
              model,
              reference,
              image_url,
              blade_type,
              avg_gentleness
            )
          `)
          .eq('user_id', user.id)
          .eq('is_favorite', true)
          .order('favorite_rating', { ascending: false, nullsLast: true })
        
        if (favoriteRazorsData) {
          setFavoriteRazors(favoriteRazorsData)
          
          // Vérifier si des ratings sont manquants et les initialiser si nécessaire
          const hasNullRatings = favoriteRazorsData.some(razor => razor.favorite_rating === null);
          if (hasNullRatings && favoriteRazorsData.length > 0) {
            console.log('Des ratings manquants détectés lors du chargement, initialisation...');
            // Attendre que l'état soit mis à jour avant d'initialiser
            setTimeout(() => initializeFavoriteRatings(), 500);
          }
        }
        
        // Récupérer tous les fabricants pour le filtre
        if (ownedRazorsData || interestedRazorsData) {
          const allManufacturers = new Set<string>()
          
          if (ownedRazorsData) {
            ownedRazorsData.forEach(razor => {
              if (razor.razors?.manufacturer) {
                allManufacturers.add(razor.razors.manufacturer)
              }
            })
          }
          
          if (interestedRazorsData) {
            interestedRazorsData.forEach(razor => {
              if (razor.razors?.manufacturer) {
                allManufacturers.add(razor.razors.manufacturer)
              }
            })
          }
          
          setManufacturers(Array.from(allManufacturers).sort())
        }
        
        setLoading(false)
      } catch (error) {
        console.error('Erreur lors de la récupération des données :', error)
        setError('Une erreur est survenue lors de la récupération des données.')
        setLoading(false)
      }
    }
    
    if (user) {
      fetchCollectionData()
    }
  }, [user, supabaseClient])
  
  if (!user) {
    return <div className="container mx-auto py-10 px-6">Chargement...</div>
  }

  return (
    <>
      <Head>
        <title>Ma Collection de Rasoirs | Relife Razor</title>
        <meta name="description" content="Gérez votre collection personnelle de rasoirs traditionnels" />
      </Head>
      
      <div className="min-h-screen py-8">
        <main className="container mx-auto px-4">
          <h1 className="text-3xl font-bold mb-10 text-high-contrast">Ma Collection de Rasoirs</h1>
          
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden mb-10 border border-gray-100 dark:border-gray-700">
            <div className="border-b border-gray-200 dark:border-gray-700">
              <nav className="flex">
                <button
                  className={`px-6 py-4 font-medium text-sm ${
                    activeTab === 'collection'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-white'
                  }`}
                  onClick={() => setActiveTab('collection')}
                >
                  Ma Collection ({ownedRazors.length})
                </button>
                <button
                  className={`px-6 py-4 font-medium text-sm ${
                    activeTab === 'wishlist'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-white'
                  }`}
                  onClick={() => setActiveTab('wishlist')}
                >
                  Ma Liste de Souhaits ({interestedRazors.length})
                </button>
                <button
                  className={`px-6 py-4 font-medium text-sm ${
                    activeTab === 'favorites'
                      ? 'border-b-2 border-primary text-primary'
                      : 'text-gray-500 hover:text-gray-700 dark:text-gray-300 dark:hover:text-white'
                  }`}
                  onClick={() => setActiveTab('favorites')}
                >
                  Mes Favoris ({favoriteRazors.length})
                </button>
              </nav>
            </div>
            
            <div className="p-6">
              {/* Filtres et recherche */}
              <div className="mb-8 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="col-span-2">
                  <label htmlFor="search" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Rechercher</label>
                  <div className="flex">
                    <input
                      type="text"
                      id="search"
                      placeholder="Rechercher par nom, fabricant, modèle..."
                      className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-slate-700 rounded-lg focus-outline"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
                
                <div>
                  <label htmlFor="manufacturer" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Fabricant</label>
                  <select
                    id="manufacturer"
                    className="w-full p-2 border border-gray-300 dark:border-gray-600 dark:bg-slate-700 rounded-lg focus-outline"
                    value={filterManufacturer}
                    onChange={(e) => setFilterManufacturer(e.target.value)}
                  >
                    <option value="">Tous les fabricants</option>
                    {manufacturers.map((manufacturer) => (
                      <option key={manufacturer} value={manufacturer}>
                        {manufacturer}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              {loading ? (
                <div className="text-center py-12">
                  <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                  <p className="mt-4 text-xl">Chargement des données...</p>
                </div>
              ) : error ? (
                <div className="text-center py-12 bg-red-50 text-red-600 rounded-lg border border-red-200 p-6">
                  <p className="text-xl font-bold">Erreur</p>
                  <p className="text-lg">{error}</p>
                </div>
              ) : (
                <div>
                  {/* Collection de rasoirs */}
                  {activeTab === 'collection' && (
                    <div>
                      <h2 className="text-2xl font-bold mb-6 text-high-contrast">Ma Collection</h2>
                      {filteredOwnedRazors.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 dark:bg-slate-700 rounded-lg">
                          <p className="text-gray-600 dark:text-gray-300 mb-4">Vous n'avez pas encore de rasoir dans votre collection.</p>
                          <Link href="/razors" className="btn-primary">
                            Parcourir les rasoirs
                          </Link>
                        </div>
                      ) : (
                        <div>
                          <div className="mb-6 flex justify-end">
                            <CollectionShareButton collectionType="owned" />
                          </div>
                          <div className="space-y-6">
                            {filteredOwnedRazors.map((item) => (
                              <RazorListItem 
                                key={`${item.razor_id}-${item.id}`}
                                razor={item.razors} 
                                collection={item}
                                showCollectionStatus={true}
                                isVariant={item.is_variant}
                                variantMaterial={item.variant_material}
                                variantFinish={item.variant_finish}
                                variantCombType={item.variant_comb_type}
                                variantNotes={item.variant_notes}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Liste de souhaits */}
                  {activeTab === 'wishlist' && (
                    <div>
                      <h2 className="text-2xl font-bold mb-6 text-high-contrast">Ma Liste de Souhaits</h2>
                      {filteredInterestedRazors.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 dark:bg-slate-700 rounded-lg">
                          <p className="text-gray-600 dark:text-gray-300 mb-4">Vous n'avez pas encore de rasoir dans votre liste de souhaits.</p>
                          <Link href="/razors" className="btn-primary">
                            Parcourir les rasoirs
                          </Link>
                        </div>
                      ) : (
                        <div>
                          <div className="mb-6 flex justify-end">
                            <CollectionShareButton collectionType="wishlist" />
                          </div>
                          <div className="space-y-6">
                            {filteredInterestedRazors.map((item) => (
                              <RazorListItem 
                                key={`${item.razor_id}-${item.id}`}
                                razor={item.razors} 
                                collection={item}
                                showCollectionStatus={true}
                                isVariant={item.is_variant}
                                variantMaterial={item.variant_material}
                                variantFinish={item.variant_finish}
                                variantCombType={item.variant_comb_type}
                                variantNotes={item.variant_notes}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Favoris */}
                  {activeTab === 'favorites' && (
                    <div>
                      <h2 className="text-2xl font-bold mb-6 text-high-contrast">Mes Rasoirs Favoris</h2>
                      {favoriteRazors.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 dark:bg-slate-700 rounded-lg">
                          <p className="text-gray-600 dark:text-gray-300 mb-4">Vous n'avez pas encore de rasoir favori.</p>
                          <Link href="/razors" className="btn-primary">
                            Parcourir les rasoirs
                          </Link>
                        </div>
                      ) : (
                        <div>
                          <div className="mb-6 flex justify-end">
                            <CollectionShareButton collectionType="favorites" />
                          </div>
                          <div className="space-y-6">
                            {favoriteRazors.map((item, index) => (
                              <RazorListItem 
                                key={`${item.razor_id}-${item.id}`}
                                razor={item.razors} 
                                collection={item}
                                showCollectionStatus={true}
                                showFavoriteRank={true}
                                position={index + 1}
                                onMoveUp={(position) => handleMoveUp(position)}
                                onMoveDown={(position) => handleMoveDown(position)}
                                onRemove={() => handleRemoveFavorite(item.razor_id)}
                                isVariant={item.is_variant}
                                variantMaterial={item.variant_material}
                                variantFinish={item.variant_finish}
                                variantCombType={item.variant_comb_type}
                                variantNotes={item.variant_notes}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </>
  )
}

export default CollectionPage
