import { createClient } from '@supabase/supabase-js';

// Ces valeurs proviennent des variables d'environnement
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

// Vérification des valeurs
if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL and Anon Key must be defined');
}

// Création du client Supabase
export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Types pour nos tables Supabase
export type Razor = Database['public']['Tables']['razors']['Row']
export type RazorInsert = Database['public']['Tables']['razors']['Insert']
export type RazorUpdate = Database['public']['Tables']['razors']['Update']

// Vérifiez si les champs que vous utilisez dans votre code existent dans le type
// Si pas encore mis à jour, complétez avec les champs manquants
export type RazorExtended = Razor & {
  material_variant?: string | null
  available_finish?: string | null
  comb_type?: string | null
  is_private?: boolean | null
  release_year?: number | null
  in_collection?: boolean | null
  favorite_rating?: number | null
}

export type Profile = {
  id: string;
  username?: string;
  full_name?: string;
  avatar_url?: string;
  website?: string;
  bio?: string;
  created_at?: string;
  is_admin: boolean;
}

export type RazorVariant = {
  id: string;
  parent_razor_id: number;
  user_id: string;
  selected_material?: string;
  selected_finish?: string;
  selected_comb_type?: string;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}

export type UserRating = {
  id: number;
  created_at: string;
  user_id: string;
  razor_id: number;
  gentleness_rating: number; // 1-20 scale
  comment?: string;
  profiles?: Profile;
}

export type UserCollection = {
  id: number;
  user_id: string;
  razor_id: number;
  in_collection?: boolean;
  in_wishlist: boolean;
  is_favorite: boolean;
  favorite_rating?: number;
  created_at: string;
  razors?: Razor; // Relation avec le rasoir
  variant_material?: string | null;
  variant_finish?: string | null;
  variant_comb_type?: string | null;
  variant_notes?: string | null;
  is_variant?: boolean | null;
}
