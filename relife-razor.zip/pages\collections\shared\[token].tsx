import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Link from 'next/link';
import { format, parseISO } from 'date-fns';
import { fr } from 'date-fns/locale';
import SafeImage from '@/components/common/SafeImage';

// Types pour les données partagées
interface SharedRazor {
  id: string;
  razor_id: string;
  is_favorite?: boolean;
  favorite_rating?: number;
  variant_material?: string;
  variant_finish?: string;
  variant_comb_type?: string;
  variant_notes?: string;
  is_variant?: boolean;
  in_wishlist?: boolean;
  razors: {
    id: string;
    manufacturer: string;
    model: string;
    reference?: string;
    image_url?: string;
    blade_type?: string;
    avg_gentleness?: number;
  };
}

interface SharedCollectionData {
  type: 'favorites' | 'owned' | 'wishlist';
  razors: SharedRazor[];
  topCount?: number;
  creator?: {
    username: string;
    rank: string;
  };
}

interface SharedCollection {
  success: boolean;
  data: SharedCollectionData;
  sharedAt: string;
  expiresAt: string;
}

const SharedCollectionPage: React.FC = () => {
  const router = useRouter();
  const { token } = router.query;
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [collectionData, setCollectionData] = useState<SharedCollectionData | null>(null);
  const [sharedInfo, setSharedInfo] = useState<{ sharedAt: string; expiresAt: string } | null>(null);

  // Récupérer les données de la collection partagée
  useEffect(() => {
    async function fetchSharedCollection() {
      if (!token) return;
      
      setIsLoading(true);
      setError(null);
      
      try {
        const response = await fetch(`/api/collections/shared/${token}`);
        const result = await response.json();
        
        if (!response.ok) {
          throw new Error(result.error || 'Erreur lors de la récupération de la collection partagée');
        }
        
        setCollectionData(result.data);
        setSharedInfo({
          sharedAt: result.sharedAt,
          expiresAt: result.expiresAt
        });
      } catch (error) {
        console.error('Error fetching shared collection:', error);
        setError('Impossible de charger la collection partagée. Ce lien est peut-être expiré ou invalide.');
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchSharedCollection();
  }, [token]);

  // Déterminer le titre de la page en fonction du type de collection
  const getCollectionTitle = () => {
    if (!collectionData) return 'Collection partagée';
    
    switch (collectionData.type) {
      case 'favorites':
        if (collectionData.topCount && collectionData.topCount > 0) {
          return collectionData.topCount === 3 
            ? 'Podium des rasoirs favoris' 
            : `Top ${collectionData.topCount} des rasoirs favoris`;
        }
        return 'Rasoirs favoris partagés';
      case 'owned':
        return 'Collection de rasoirs partagée';
      case 'wishlist':
        return 'Liste de souhaits partagée';
      default:
        return 'Collection partagée';
    }
  };

  // Déterminer l'icône pour le titre
  const getCollectionIcon = () => {
    if (!collectionData) return '📋';
    
    switch (collectionData.type) {
      case 'favorites':
        if (collectionData.topCount && collectionData.topCount > 0) {
          return collectionData.topCount === 3 ? '🏆' : '🔝';
        }
        return '⭐';
      case 'owned':
        return '🪒';
      case 'wishlist':
        return '🎁';
      default:
        return '📋';
    }
  };

  return (
    <>
      <Head>
        <title>{getCollectionTitle()} - Relife Razor</title>
        <meta name="description" content="Collection de rasoirs partagée sur Relife Razor" />
      </Head>

      <div className="container mx-auto px-4 py-8 max-w-5xl">
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500 mb-4"></div>
            <p>Chargement de la collection partagée...</p>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <h2 className="text-red-600 text-xl font-medium mb-4">Erreur</h2>
            <p className="text-red-700">{error}</p>
            <div className="mt-6">
              <Link href="/" className="text-blue-600 hover:underline">
                Retour à l'accueil
              </Link>
            </div>
          </div>
        ) : collectionData && sharedInfo ? (
          <>
            <div className="bg-white shadow rounded-lg p-6">
              <h1 className="text-2xl font-bold mb-2 flex items-center">
                <span className="mr-2">{getCollectionIcon()}</span>
                {getCollectionTitle()}
              </h1>
              
              {collectionData.creator && (
                <div className="mb-4">
                  <div className="flex flex-wrap items-center text-gray-700 mb-2">
                    <span className="text-sm mr-2">Collection de</span>
                    <span className="font-medium text-gray-900">{collectionData.creator.username}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <span className="px-2 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full flex items-center">
                      <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                      </svg>
                      {collectionData.creator.rank}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="mb-6 text-sm text-gray-600">
                <p>
                  Partagé le {format(parseISO(sharedInfo.sharedAt), 'PPP', { locale: fr })}
                  {' • '}
                  Expire le {format(parseISO(sharedInfo.expiresAt), 'PPP', { locale: fr })}
                </p>
              </div>
              
              {collectionData.razors.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p>Cette collection ne contient aucun rasoir.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {collectionData.type === 'favorites' && collectionData.topCount && collectionData.topCount > 0 && (
                    <div className="col-span-full mb-4">
                      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-lg p-4 text-center">
                        <h2 className="text-xl font-semibold text-blue-800">
                          {collectionData.topCount === 3 ? 'Podium des favoris' : `Top ${collectionData.topCount} des favoris`}
                        </h2>
                        <p className="text-sm text-blue-600 mt-1">
                          Classement personnel par {collectionData.creator?.username || 'l\'utilisateur'}
                        </p>
                      </div>
                    </div>
                  )}
                
                  {collectionData.razors.map((item, index) => (
                    <div
                      key={item.id}
                      className={`border rounded-lg overflow-hidden bg-white shadow-sm hover:shadow-md transition ${
                        collectionData.type === 'favorites' && index < (collectionData.topCount || 3)
                          ? 'relative border-2' + 
                            (index === 0 ? ' border-yellow-400 shadow-lg' : 
                             index === 1 ? ' border-gray-400' : 
                             index === 2 ? ' border-amber-600' :
                             ' border-blue-300')
                          : ''
                      }`}
                      style={{
                        transform: collectionData.type === 'favorites' && index < (collectionData.topCount || 3)
                          ? `translateY(${Math.min(index, 5) * -3 + 5}px) scale(${1 - (Math.min(index, 5) * 0.01)})`
                          : 'none',
                        zIndex: collectionData.type === 'favorites' && index < (collectionData.topCount || 3)
                          ? 20 - index
                          : 1
                      }}
                    >
                      <div className="aspect-w-16 aspect-h-9 bg-gray-100 relative">
                        <SafeImage
                          src={item.razors.image_url || '/images/razor-placeholder.jpg'}
                          alt={`${item.razors.manufacturer} ${item.razors.model}`}
                          className="object-cover"
                          width={300}
                          height={200}
                        />
                        {collectionData.type === 'favorites' && (
                          <div className="absolute top-0 left-0 w-full p-2">
                            <div className={`bg-blue-500 text-white px-3 py-1 rounded-lg shadow-md font-medium ${
                              index < 3 ? 'px-3 py-2 font-bold text-lg' : ''
                            }`} style={{
                              backgroundColor: index === 0 ? '#f59e0b' : 
                                              index === 1 ? '#9ca3af' : 
                                              index === 2 ? '#b45309' : 
                                              '#3b82f6'
                            }}>
                              #{index + 1}
                            </div>
                          </div>
                        )}
                      </div>
                      
                      <div className="p-4">
                        <div className="flex justify-between items-start">
                          <h3 className="font-medium">
                            {item.razors.manufacturer} {item.razors.model}
                            {item.razors.reference && ` (${item.razors.reference})`}
                          </h3>
                          
                          {collectionData.type === 'wishlist' && (
                            <div className="ml-2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                              Souhaité
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-2 text-sm text-gray-600">
                          {item.razors.blade_type && (
                            <div className="mt-1">
                              <span className="font-medium">Type de lame:</span> {item.razors.blade_type}
                            </div>
                          )}
                          
                          {item.razors.avg_gentleness !== undefined && (
                            <div className="mt-1">
                              <span className="font-medium">Douceur:</span>{' '}
                              {item.razors.avg_gentleness}/20
                              {(() => {
                                // Utiliser la valeur directement sans division
                                const gentlenessValue = item.razors.avg_gentleness;
                                let label = '';
                                let color = '';
                                
                                if (gentlenessValue >= 1 && gentlenessValue <= 3) {
                                  label = 'Très doux';
                                  color = '#fff176';
                                } else if (gentlenessValue >= 4 && gentlenessValue <= 7) {
                                  label = 'Doux';
                                  color = '#f9bd59';
                                } else if (gentlenessValue >= 8 && gentlenessValue <= 12) {
                                  label = 'Intermédiaire';
                                  color = '#e8863b';
                                } else if (gentlenessValue >= 13 && gentlenessValue <= 17) {
                                  label = 'Agressif';
                                  color = '#d03c1f';
                                } else {
                                  label = 'Très agressif';
                                  color = '#7e0404';
                                }
                                
                                return (
                                  <div className="mb-2">
                                    <div 
                                      className="inline-block w-4 h-4 rounded-full mr-2 border border-black" 
                                      style={{ backgroundColor: color }}
                                    ></div>
                                    <span className="text-xs">
                                      {label}
                                    </span>
                                  </div>
                                );
                              })()}
                            </div>
                          )}

                          {(item.variant_material || item.variant_finish || item.variant_comb_type) && (
                            <div className="mt-2 pt-2 border-t border-gray-100">
                              <span className="font-medium">Variante:</span>
                              <ul className="list-disc list-inside ml-2 mt-1">
                                {item.variant_material && <li>Matériau: {item.variant_material}</li>}
                                {item.variant_finish && <li>Finition: {item.variant_finish}</li>}
                                {item.variant_comb_type && <li>Type de peigne: {item.variant_comb_type}</li>}
                              </ul>
                            </div>
                          )}

                          {item.variant_notes && (
                            <div className="mt-2">
                              <span className="font-medium">Notes:</span> {item.variant_notes}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                <Link 
                  href="/"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  <span className="mr-2">🏠</span>
                  Visiter Relife Razor
                </Link>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </>
  );
};

export default SharedCollectionPage;
