import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useSupabaseClient } from '@supabase/auth-helpers-react'
import GentlenessScale from '../components/razors/GentlenessScale'
import { Razor } from '../lib/supabase'
import { getComparisonList, addToComparisonList, removeFromComparisonList } from '../lib/compareService'
import Link from 'next/link'

const ComparePage = () => {
  const router = useRouter()
  const supabaseClient = useSupabaseClient()
  const [razors, setRazors] = useState<Razor[]>([])
  const [selectedRazors, setSelectedRazors] = useState<Razor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // Couleurs des marqueurs pour l'échelle et le tableau
  const markerColors = [
    'bg-red-500 text-white',
    'bg-blue-500 text-white',
    'bg-green-500 text-white',
    'bg-amber-500 text-white'
  ]
  
  // Charger tous les rasoirs au chargement de la page
  useEffect(() => {
    const loadRazors = async () => {
      setLoading(true)
      setError(null)
      
      try {
        const { data, error } = await supabaseClient.from('razors').select('*')
        
        if (error) throw error
        
        setRazors(data || [])
      } catch (err: any) {
        console.error('Error loading razors:', err)
        setError('Impossible de charger les rasoirs')
      } finally {
        setLoading(false)
      }
    }
    
    loadRazors()
  }, [])
  
  // Préselectionner les rasoirs à partir des paramètres d'URL
  useEffect(() => {
    if (!router.isReady || !razors.length) return
    
    const { razors: razorParam } = router.query
    
    if (razorParam) {
      try {
        // Gérer à la fois un seul ID et plusieurs IDs séparés par des virgules
        const razorIds = Array.isArray(razorParam) 
          ? razorParam[0].split(',').map(id => parseInt(id, 10))
          : razorParam.split(',').map(id => parseInt(id, 10))
        
        // Filtrer les IDs invalides
        const validIds = razorIds.filter(id => !isNaN(id))
        
        // Trouver les rasoirs correspondants
        const preselectedRazors = razors.filter(razor => validIds.includes(razor.id))
        
        if (preselectedRazors.length > 0) {
          setSelectedRazors(preselectedRazors)
          console.log('Rasoirs présélectionnés:', preselectedRazors)
        }
      } catch (err) {
        console.error('Erreur lors de la présélection des rasoirs:', err)
      }
    } else {
      // Si pas de paramètre d'URL, charger depuis localStorage
      const storedIds = getComparisonList();
      if (storedIds.length > 0) {
        const storedRazors = razors.filter(razor => storedIds.includes(razor.id));
        setSelectedRazors(storedRazors);
        console.log('Rasoirs chargés depuis localStorage:', storedRazors);
      }
    }
  }, [router.isReady, router.query, razors])
  
  // Fonction pour retirer un rasoir de la comparaison
  const removeFromComparison = (razorId) => {
    const updatedRazors = selectedRazors.filter(razor => razor.id !== razorId);
    setSelectedRazors(updatedRazors);
    // Mettre à jour le localStorage
    removeFromComparisonList(razorId);
    updateQueryParams(updatedRazors.map(r => r.id));
  };
  
  // Partage de la comparaison (URL avec paramètres)
  const shareComparison = () => {
    const url = new URL(window.location.href)
    url.search = `?ids=${selectedRazors.map(r => r.id).join(',')}`
    
    navigator.clipboard.writeText(url.toString())
      .then(() => alert('Lien de comparaison copié dans le presse-papier!'))
      .catch(err => console.error('Impossible de copier le lien:', err))
  }
  
  // Rafraîchissement de la page
  const refreshPage = () => {
    window.location.reload()
  }
  
  // Mise à jour des paramètres d'URL
  const updateQueryParams = (razorIds: number[]) => {
    if (razorIds.length > 0) {
      const url = new URL(window.location.href);
      url.search = `?ids=${razorIds.join(',')}`;
      window.history.pushState({}, '', url.toString());
    } else {
      window.history.pushState({}, '', window.location.pathname);
    }
  };
  
  return (
    <div className="min-h-screen py-8">
      <Head>
        <title>Comparer les Rasoirs | Relife Razor</title>
        <meta name="description" content="Comparez différents rasoirs traditionnels côte à côte" />
      </Head>
      
      <main className="container mx-auto px-4">
        <h1 className="text-3xl font-bold mb-6">Comparer les Rasoirs</h1>
        
        {/* Zone de comparaison */}
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow p-6 mb-8">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">Rasoirs sélectionnés ({selectedRazors.length})</h2>
            
            {selectedRazors.length > 0 && (
              <div className="flex gap-2">
                <button 
                  onClick={shareComparison}
                  className="btn-secondary"
                >
                  Partager cette comparaison
                </button>
                
                <button 
                  onClick={refreshPage}
                  className="btn-secondary"
                >
                  Rafraîchir
                </button>
              </div>
            )}
          </div>
          
          {selectedRazors.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 dark:bg-slate-700 rounded-lg">
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                Aucun rasoir sélectionné pour la comparaison
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Ajoutez des rasoirs à comparer depuis la page des rasoirs ou depuis la page de détail d'un rasoir
              </p>
              <button
                onClick={() => router.push('/razors')}
                className="mt-4 px-4 py-2 bg-primary text-white rounded hover:bg-primary-dark transition-colors"
              >
                Voir tous les rasoirs
              </button>
            </div>
          ) : (
            <>
              {/* Échelle de douceur */}
              <h2 className="text-xl font-semibold">Échelle de comparaison de douceur</h2>
              <div className="mt-4">
                {/* Affichage de l'échelle avec tous les rasoirs sélectionnés */}
                <GentlenessScale razors={selectedRazors} showLabels={false} razorlabels={true} compact={false} />
                {/* Légende des rasoirs */}
                <div className="mt-8 bg-white dark:bg-slate-800 p-4 rounded shadow">
                  <h3 className="text-lg font-medium mb-2">Référence des rasoirs sélectionnés</h3>
                  <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-2">
                    {selectedRazors.map((razor, index) => {
                      return (
                        <div key={razor.id} className="flex items-center">
                          <div className={`w-6 h-6 rounded-full ${markerColors[index % markerColors.length]} mr-2 flex items-center justify-center font-bold text-xs`}>{index+1}</div>
                          <div className="text-sm">
                            <div>
                              {razor.model}
                              {razor.reference && <span> - {razor.reference}</span>} 
                              <span className="ml-1">({razor.avg_gentleness}/20)</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
              
              {/* Tableau comparatif */}
              <div className="overflow-x-auto mt-6">
                <table className="w-full border-collapse bg-white dark:bg-slate-800 shadow rounded-lg text-left">
                  <thead>
                    <tr className="bg-gray-50 dark:bg-slate-700">
                      <th className="p-3 border-b">Caractéristique</th>
                      {selectedRazors.map((razor, index) => (
                        <th key={razor.id} className="p-3 border-b">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center">
                              <div className={`w-6 h-6 rounded-full mr-2 flex items-center justify-center ${markerColors[index % markerColors.length]}`}>
                                {index + 1}
                              </div>
                              <span>
                                {razor.model}
                                {razor.reference && <span> - {razor.reference}</span>}
                              </span>
                            </div>
                            <button 
                              onClick={() => removeFromComparison(razor.id)}
                              className="text-red-500 hover:text-red-700 ml-2"
                            >
                              ✖️
                            </button>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="p-3 border-b font-medium">Référence</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.reference || '-'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">Type de lame</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.blade_type}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">Douceur</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          <div className="flex items-center">
                            <span className="font-medium">{razor.avg_gentleness}/20</span>
                          </div>
                        </td>
                      ))}
                    </tr>
                    
                    {/* Nouvelles spécifications techniques */}
                    <tr>
                      <td className="p-3 border-b font-medium">Poids</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.weight_grams ? `${razor.weight_grams} g` : '-'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">GAP</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.gap_mm ? `${razor.gap_mm} mm` : '-'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">Exposition de lame</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.blade_exposure_mm ? `${razor.blade_exposure_mm} mm` : '-'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">Angle de coupe</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.cutting_angle ? `${razor.cutting_angle}°` : '-'}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="p-3 border-b font-medium">Prix</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.price ? `${razor.price} €` : '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <td className="p-3 border-b font-medium">Informations additionnelles</td>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-3 border-b">
                          {razor.additional_info || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Angle de coupe</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.cutting_angle ? `${razor.cutting_angle}°` : '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Matériau de base</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.base_material || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Variante de matière</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.material_variant || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Finition disponible</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.available_finish || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Type de peigne</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.comb_type || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Année de mise en vente</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          {razor.release_year || '-'}
                        </td>
                      ))}
                    </tr>
                    
                    {/* Bouton pour accéder à la fiche détaillée */}
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Fiche détaillée</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          <Link 
                            href={`/razors/${razor.id}`}
                            className="inline-block px-3 py-2 bg-primary text-white rounded hover:bg-primary-dark transition-colors w-full text-center"
                          >
                            Voir la fiche
                          </Link>
                        </td>
                      ))}
                    </tr>
                    
                    {/* Bouton pour retirer de la comparaison */}
                    <tr>
                      <th className="text-left p-2 bg-gray-100 dark:bg-gray-700">Actions</th>
                      {selectedRazors.map((razor) => (
                        <td key={razor.id} className="p-2 border-b">
                          <button
                            onClick={() => removeFromComparison(razor.id)}
                            className="inline-block px-3 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition-colors w-full text-center"
                          >
                            Retirer
                          </button>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  )
}

export default ComparePage
