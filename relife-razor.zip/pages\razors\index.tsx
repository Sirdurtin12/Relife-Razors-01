import React, { useState, useEffect } from 'react'
import Head from 'next/head'
import Link from 'next/link'
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react'
import { Razor } from '../../lib/supabase'
import RazorListItem from '../../components/razors/RazorListItem'
import GentlenessGuide from '../../components/razors/GentlenessGuide'

const RazorsPage = () => {
  const supabaseClient = useSupabaseClient()
  const user = useUser()
  const [razors, setRazors] = useState<Razor[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  
  // Filtres
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState<string>('')
  const [gentlenessRange, setGentlenessRange] = useState<[number, number]>([1, 20])
  const [selectedManufacturer, setSelectedManufacturer] = useState<string>('')
  const [releaseYearRange, setReleaseYearRange] = useState<[number, number]>([1900, 2025])
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500])
  
  // Liste des types de rasoirs disponibles
  const razorTypes = ['DE', 'AC', 'GEM', 'other']
  const [manufacturers, setManufacturers] = useState<string[]>([])
  
  // Vérifier si l'utilisateur est administrateur
  useEffect(() => {
    const checkAdmin = async () => {
      if (!user) {
        setIsAdmin(false)
        return
      }
      
      try {
        const { data } = await supabaseClient
          .from('admins')
          .select('*')
          .eq('user_id', user.id)
          .single()
        
        setIsAdmin(!!data)
      } catch (err) {
        setIsAdmin(false)
      }
    }
    
    checkAdmin()
  }, [user])

  // Fonction pour charger les rasoirs depuis Supabase
  const loadRazors = async () => {
    setLoading(true)
    setError(null)
    
    try {
      let query = supabaseClient.from('razors').select('*')
      
      // N'afficher que les rasoirs non privés (les variantes sont privées)
      query = query.eq('is_private', false)
      
      // Appliquer les filtres
      if (selectedType) {
        query = query.eq('blade_type', selectedType)
      }
      
      if (selectedManufacturer) {
        query = query.eq('manufacturer', selectedManufacturer)
      }
      
      query = query.gte('avg_gentleness', gentlenessRange[0])
        .lte('avg_gentleness', gentlenessRange[1])
        
      // Filtre par année de mise en vente
      if (releaseYearRange[0] !== 1900 || releaseYearRange[1] !== 2025) {
        query = query.gte('release_year', releaseYearRange[0])
          .lte('release_year', releaseYearRange[1])
      }
      
      // Filtre par prix
      if (priceRange[0] !== 0 || priceRange[1] !== 500) {
        query = query.gte('price', priceRange[0])
          .lte('price', priceRange[1])
      }
      
      // Recherche textuelle
      if (searchTerm) {
        query = query.or(`manufacturer.ilike.%${searchTerm}%,model.ilike.%${searchTerm}%,reference.ilike.%${searchTerm}%`)
      }
      
      const { data, error } = await query
      
      if (error) throw error
      
      setRazors(data || [])
    } catch (err: any) {
      console.error('Error loading razors:', err)
      setError('Impossible de charger les rasoirs')
    } finally {
      setLoading(false)
    }
  }
  
  // Charger les fabricants disponibles
  const loadManufacturers = async () => {
    try {
      const { data, error } = await supabaseClient
        .from('razors')
        .select('manufacturer')
        .eq('is_private', false)
        .order('manufacturer', { ascending: true })
      
      if (error) throw error
      
      // Extraire les fabricants uniques
      const uniqueManufacturers = [...new Set(data.map(item => item.manufacturer))]
        .filter(manufacturer => manufacturer) // Filtrer les valeurs null/undefined
      
      setManufacturers(uniqueManufacturers)
    } catch (err) {
      console.error('Error loading manufacturers:', err)
    }
  }
  
  // Charger les rasoirs au chargement de la page et les fabricants
  useEffect(() => {
    loadManufacturers()
    loadRazors()
  }, [])
  
  // Recharger les rasoirs lorsque les filtres changent
  useEffect(() => {
    const timer = setTimeout(() => {
      loadRazors()
    }, 300)

    return () => clearTimeout(timer)
  }, [selectedType, selectedManufacturer, gentlenessRange, releaseYearRange, priceRange])
  
  // Gérer la recherche manuelle (pour éviter trop de requêtes pendant la frappe)
  const handleSearch = () => {
    loadRazors()
  }
  
  return (
    <div className="min-h-screen py-8">
      <Head>
        <title>Explorer les Rasoirs | Relife Razor</title>
        <meta name="description" content="Découvrez et comparez tous les rasoirs traditionnels" />
      </Head>
      
      <main className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-high-contrast">Explorer les Rasoirs</h1>
          {user && (
            <Link href="/razors/add" className="btn-primary">
              Ajouter un rasoir
            </Link>
          )}
        </div>
        
        {/* Guide de douceur */}
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-10 border border-gray-100 dark:border-gray-700">
          <GentlenessGuide className="highlight" />
        </div>

        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8 mb-10 border border-gray-100 dark:border-gray-700">
          <h2 className="text-2xl md:text-3xl font-bold mb-8 text-high-contrast">Filtrer les Rasoirs</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Recherche textuelle */}
            <div>
              <label htmlFor="search" className="block text-lg font-medium mb-2 text-medium-contrast">
                Recherche
              </label>
              <div className="flex">
                <input
                  id="search"
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Marque, modèle..."
                  className="input-field rounded-r-none focus-outline"
                  aria-label="Rechercher un rasoir par marque ou modèle"
                />
                <button
                  onClick={handleSearch}
                  className="bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-r-lg focus-outline"
                  aria-label="Rechercher"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </button>
              </div>
            </div>
            
            {/* Filtre par type */}
            <div>
              <label htmlFor="type" className="block text-lg font-medium mb-2 text-medium-contrast">
                Type de lame
              </label>
              <select
                id="type"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="input-field focus-outline"
                aria-label="Filtrer par type de lame"
              >
                <option value="">Tous les types</option>
                {razorTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Filtre par fabricant */}
            <div>
              <label htmlFor="manufacturer" className="block text-lg font-medium mb-2 text-medium-contrast">
                Fabricant
              </label>
              <select
                id="manufacturer"
                value={selectedManufacturer}
                onChange={(e) => setSelectedManufacturer(e.target.value)}
                className="input-field focus-outline"
                aria-label="Filtrer par fabricant"
              >
                <option value="">Tous les fabricants</option>
                {manufacturers.map((manufacturer) => (
                  <option key={manufacturer} value={manufacturer}>
                    {manufacturer}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Filtre par niveau de douceur */}
            <div>
              <label className="block text-lg font-medium mb-2 text-medium-contrast">
                Niveau de douceur: {gentlenessRange[0]} - {gentlenessRange[1]}
              </label>
              <div className="flex flex-col space-y-4">
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Min</span>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    value={gentlenessRange[0]}
                    onChange={(e) => setGentlenessRange([parseInt(e.target.value), gentlenessRange[1]])}
                    className="flex-1 h-3"
                    aria-label="Niveau de douceur minimum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{gentlenessRange[0]}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Max</span>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    value={gentlenessRange[1]}
                    onChange={(e) => setGentlenessRange([gentlenessRange[0], parseInt(e.target.value)])}
                    className="flex-1 h-3"
                    aria-label="Niveau de douceur maximum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{gentlenessRange[1]}</span>
                </div>
              </div>
              <div className="flex justify-between text-sm text-medium-contrast mt-2">
                <span>1 = Très doux</span>
                <span>20 = Très agressif</span>
              </div>
            </div>
            
            {/* Filtre par année de sortie */}
            <div>
              <label className="block text-lg font-medium mb-2 text-medium-contrast">
                Année de sortie: {releaseYearRange[0]} - {releaseYearRange[1]}
              </label>
              <div className="flex flex-col space-y-4">
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Min</span>
                  <input
                    type="range"
                    min="1900"
                    max="2025"
                    value={releaseYearRange[0]}
                    onChange={(e) => setReleaseYearRange([parseInt(e.target.value), releaseYearRange[1]])}
                    className="flex-1 h-3"
                    aria-label="Année de sortie minimum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{releaseYearRange[0]}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Max</span>
                  <input
                    type="range"
                    min="1900"
                    max="2025"
                    value={releaseYearRange[1]}
                    onChange={(e) => setReleaseYearRange([releaseYearRange[0], parseInt(e.target.value)])}
                    className="flex-1 h-3"
                    aria-label="Année de sortie maximum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{releaseYearRange[1]}</span>
                </div>
              </div>
            </div>
            
            {/* Filtre par prix */}
            <div>
              <label className="block text-lg font-medium mb-2 text-medium-contrast">
                Prix: {priceRange[0]} - {priceRange[1]}
              </label>
              <div className="flex flex-col space-y-4">
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Min</span>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    value={priceRange[0]}
                    onChange={(e) => setPriceRange([parseInt(e.target.value), priceRange[1]])}
                    className="flex-1 h-3"
                    aria-label="Prix minimum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{priceRange[0]}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-base font-bold min-w-[30px] text-center">Max</span>
                  <input
                    type="range"
                    min="0"
                    max="500"
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                    className="flex-1 h-3"
                    aria-label="Prix maximum"
                  />
                  <span className="text-lg font-bold min-w-[40px] text-center">{priceRange[1]}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Liste des rasoirs */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            <p className="mt-4 text-xl">Chargement des rasoirs...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12 bg-red-50 text-red-600 rounded-lg border border-red-200 p-6">
            <p className="text-xl font-bold">Erreur</p>
            <p className="text-lg">{error}</p>
          </div>
        ) : razors.length === 0 ? (
          <div className="text-center py-12 bg-blue-50 text-blue-600 rounded-lg border border-blue-200 p-6">
            <p className="text-xl font-bold">Aucun rasoir ne correspond à vos critères</p>
            <p className="text-lg mt-2">Essayez d'élargir vos critères de recherche</p>
          </div>
        ) : (
          <div className="space-y-6 mb-12">
            {razors.map((razor) => (
              <RazorListItem 
                key={razor.id} 
                razor={razor} 
                isAdmin={isAdmin}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

export default RazorsPage
